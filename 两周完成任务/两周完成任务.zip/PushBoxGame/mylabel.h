#ifndef MYLABEL_H
#define MYLABEL_H

#include <QLabel>

class myLabel : public QLabel
{
    Q_OBJECT
public:
    myLabel();
signals:

public slots:
};

#endif // MYLABEL_H
