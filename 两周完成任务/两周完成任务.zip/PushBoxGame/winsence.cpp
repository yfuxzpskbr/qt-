#include "winsence.h"

winsence::winsence(QWidget *parent) : QMainWindow(parent)
{

}
