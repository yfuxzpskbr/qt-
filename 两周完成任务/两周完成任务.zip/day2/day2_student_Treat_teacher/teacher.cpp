#include "teacher.h"

teacher::teacher(QObject *parent) : QObject(parent)
{

}
