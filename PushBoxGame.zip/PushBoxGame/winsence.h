#ifndef WINSENCE_H
#define WINSENCE_H

#include <QMainWindow>

class winsence : public QMainWindow
{
    Q_OBJECT
public:
    explicit winsence(QWidget *parent = 0);

signals:

public slots:
};

#endif // WINSENCE_H